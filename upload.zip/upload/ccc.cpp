#include<iostream>
using namespace std;

main()
{
     std::cout<<"asdsa" ;
}