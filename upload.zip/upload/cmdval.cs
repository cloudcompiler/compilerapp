using System;
 
namespace Chapter1
{
  class Program
   {
     static void Main(string[] args)
      {

System.Diagnostics.Process proc = new System.Diagnostics.Process(); 
proc.StartInfo.FileName = "gcc.exe";
proc.StartInfo.Arguments = "AREA.C"; 
proc.StartInfo.UseShellExecute = false;
proc.StartInfo.RedirectStandardOutput = true; 
proc.Start();

      }
   }
}