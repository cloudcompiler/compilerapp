<?php
/*
 // $disabled = explode(', ', ini_get('disable_functions'));
// print($disabled);

//exec('gcc AREA.C -o hello.exe' , $result);
//print($result);
//exec('./hello.exe' , $result);
//echo $result;


//$tmp = exec("gcc AREA.C -o hello.exe", $results);

$tmp = exec(escapeshellcmd("gcc AREA.C -o hello.exe"),$results);

foreach ($results as $row) echo $row . "<br>";
echo "done";


$i = 0;
//chmod('AREA.C', 0755); 

chmod('C:\TDM-GCC-32\bin\gcc.exe',0755);

exec('gcc AREA.C', $response);
foreach($response as $line) {
 
  $line = $line;
 
  if (strpos($line, "DNS")>0) {
    print (trim($line));
    echo ("\n");
    }
}



$cmd='C:\TDM-GCC-32\bin\gcc.exe C:\xampp\htdocs\owncloud\apps\compilerapp\upload\AREA.C';
$output="";

exec($cmd, $output);
    if (!$output) {

        $output = array();
        $handle = proc_open($cmd, array(1 => array('pipe', 'w')), $pipes, null, null, array('bypass_shell' => true));
        if (is_resource($handle)) {
            $output = explode("\n", stream_get_contents($pipes[1]));
            fclose($pipes[1]);
            proc_close($handle);
        }
    }
   echo $output;

*/


//$cmd='C:\TDM-GCC-32\bin\gcc.exe C:\xampp\htdocs\owncloud\apps\compilerapp\upload\AREA.C';

$cmd='gcc -o C:\xampp\htdocs\owncloud\apps\compilerapp\upload\helo.exe C:\xampp\htdocs\owncloud\apps\compilerapp\upload\AREA.C';

   $descriptorspec = array(
           0 => array("pipe", "r"), // stdin
           1 => array("pipe", "w"), // stdout
           2 => array("pipe", "w") // stderr
        );
       
        $process = proc_open($cmd, $descriptorspec, $pipes, null);

        while (!feof($pipes[1])) {
            foreach($pipes as $key =>$pipe) {
                $line = fread($pipe, 14000);
                if($line) {
                    print($line);
					echo "<br>";
                   // $this->log($line);
                }
            }
            sleep(0.5);
        }