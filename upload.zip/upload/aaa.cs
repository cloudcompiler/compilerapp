using System;
 
namespace Chapter1
{
  class Program
   {
     static void Main(string[] args)
      {
        Console.WriteLine("This is my First C# Program");
		Console.WriteLine("First Name is " + args[0]);
		Console.WriteLine("First Name is " + args[1]);
      }
   }
}