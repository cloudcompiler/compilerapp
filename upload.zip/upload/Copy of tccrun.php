<?php

if(isset($_GET['FileNam']))
{
$fnm=$_GET['FileNam'];

$Parameter=$_GET['Parameter'];

$result =`tcc $fnm `;
//echo $result;


$err="Y";
if(strpos($result,"error")>=1 or strpos($result,"error")>=1)
	{
$err="N";
echo "<br><br><b>Compile : </b><br><br>";
echo $result;
	}

	if($err=="Y")
	{
echo "<br><br><b>Compile : </b><br><br>";
echo $result;

$newfnm=explode(".",$fnm);
echo "<br><br><b>Result : </b><br><br>";
$result =`$newfnm[0] `;

//exec($newfnm[0],$result);

echo $result;
	}


}

?>
