<?php

if(isset($_GET['FileNam']))
{
$fnm=$_GET['FileNam'];
$Parameter=$_GET['Parameter'];

$result =`java Csharpcompiler $fnm `;

$err="Y";
if(strpos($result,"error")>=1 or strpos($result,"error")>=1)
	{
$err="N";
echo "<br><br><b>Compile : </b><br><br>";
echo $result;
	}

	if($err=="Y")
	{
echo "<br><br><b>Compile : </b><br><br>";
echo $result;

$newfnm=explode(".",$fnm);
echo "<br><br><b>Result : </b><br><br>";
$result =`$newfnm[0] $Parameter `;
echo $result;
	}

}

?>
