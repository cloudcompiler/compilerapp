<?php
if(isset($_GET['FileNam']))
{
$fnm=$_GET['FileNam'];
$Parameter=$_GET['Parameter'];
$newfnm=explode(".",$fnm).".exe";
$result ="";
$cmd="";
//$cmd='C:\TDM-GCC-32\bin\gcc.exe C:\xampp\htdocs\owncloud\apps\compilerapp\upload\AREA.C';

if(substr_count($fnm,"cpp")>0 or substr_count($fnm,"CPP")>0){
$cmd="g++ -o C:\\xampp\\htdocs\\owncloud\\apps\\compilerapp\\upload\\".$newfnm." C:\\xampp\\htdocs\\owncloud\\apps\\compilerapp\\upload\\".$fnm;
}else
	{
$cmd="gcc -o C:\\xampp\\htdocs\\owncloud\\apps\\compilerapp\\upload\\".$newfnm." C:\\xampp\\htdocs\\owncloud\\apps\\compilerapp\\upload\\".$fnm;
	}

//echo $cmd;

   $descriptorspec = array(
           0 => array("pipe", "r"), // stdin
           1 => array("pipe", "w"), // stdout
           2 => array("pipe", "w") // stderr
        );
       
        $process = proc_open($cmd, $descriptorspec, $pipes, null);

        while (!feof($pipes[1])) {
            foreach($pipes as $key =>$pipe) {
                $line = fread($pipe, 14000);
                if($line) {
					$result.=$line;
                    print($line);
					echo "<br>";
                   // $this->log($line);
                }
            }
            sleep(0.5);
        }


$err="Y";
if(strpos($result,"error")>=1 or strpos($result,"error")>=1)
	{
$err="N";
echo "<br><br><b>Compile : </b><br><br>";
echo $result;
	}

	if($err=="Y")
	{
echo "<br><br><b>Compile : </b><br><br>";
echo "No Error :".$result;

echo "<br><br><b>Result : </b><br><br>";
$result =`$newfnm $Parameter `;
echo $result;
	}


}
?>