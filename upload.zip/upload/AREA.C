#include<stdio.h>
main()
{
printf("\n enter radius of cercle");
return 0;
}








