import java.io.*;

class ron
{

String s1=new String("This Is Java");
String s2=new String(s1);

StringBuffer sb1=new StringBuffer("This Is Java");
StringBuffer sb2=new StringBuffer(sb1);


void stfun()
{

boolean e;
char buff[]=new char[3];

System.out.println("Length of String:-"+s1.length());
System.out.println("charAt 2 of String:-"+s1.charAt(2));
System.out.println("equals of String:-"+s1.equals(s2));


s1.getChars(0,3,buff,0);
System.out.println(buff);

System.out.println("Startwith of String:-"+s2.startsWith("rrrr"));
System.out.println("endtwith of String:-"+s2.endsWith("rrrr"));


System.out.println("Substring of String:-"+s1.substring(3,4));


System.out.println("concat of String:-"+"dddddd".concat("mkm"));

String s3=new String(s1.concat(s2));
System.out.println("concat of String:-"+s3);

System.out.println("Uppercase of String:-"+s1.toUpperCase());
System.out.println("Lowercase of String:-"+s1.toLowerCase());

}


void stbfun()
{
System.out.println("Capacity of String:-"+sb1.capacity());

sb1.append(" ghgh");
System.out.println("Append of String:-"+sb1);

sb1.insert(5,"ghgh");
System.out.println("insert of String:-"+sb1);

StringBuffer sb3=sb1.deleteCharAt(8);
System.out.println("delete of String:-"+sb3);

sb1.reverse();
System.out.println("reverse of String:-"+sb1);

sb1.replace(5,10,"rrrrr");
System.out.println("replace of String:-"+sb1);



}


}



class prr
{
	public static void main(String args[])
	{
	ron rr1=new ron();
	rr1.stfun();
	rr1.stbfun();	
	}
}