import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.applet.*;
import java.io.*;
class Csharpcompiler
{

	private static void printLines(String name, InputStream ins) throws Exception {
    String line = null;
    BufferedReader in = new BufferedReader(
        new InputStreamReader(ins));
    while ((line = in.readLine()) != null) {
        System.out.println(name + " " + line);
		System.out.println("<br>");
    }
  }

  private static void runProcess(String command) throws Exception {
    Process pro = Runtime.getRuntime().exec(command);
    printLines(command + " stdout:", pro.getInputStream());
    printLines(command + " stderr:", pro.getErrorStream());
    pro.waitFor();
    System.out.println(command + " exitValue() " + pro.exitValue());
  }

  public static void main(String[] args) {
    try {
		
		runProcess("csc "+args[0]);

	  //String ss="args[0]";
	  //String[] s1=ss.split(".");
	  //runProcess("java "+s1[0]);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

/*
public static void main(String args[]){

try{
	Process pro1 = Runtime.getRuntime().exec("javac Akey.java");
    pro1.waitFor();
    //Process pro2 = Runtime.getRuntime().exec("java Main");

    BufferedReader in = new BufferedReader(new InputStreamReader(pro1.getInputStream()));
    String line = null;

    while ((line = in.readLine()) != null) {
        System.out.println(line);
    }
}
catch(Exception ee){}

}	
*/

}
	