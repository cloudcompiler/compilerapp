import java.io.*;

class aaa
{
	public static void main(String args[])
	{
		int a=10,b=40;
		int c=a+b;
System.out.println(c);
System.out.println(args[0]);
	}
}